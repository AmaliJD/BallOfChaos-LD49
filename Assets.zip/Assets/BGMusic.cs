using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class BGMusic : MonoBehaviour
{
    GameManager gamemanager;
    AudioSource bgmusic;

    float prevVolume;
    int loadedCount = 0;

    private void Awake()
    {
        gamemanager = FindObjectOfType<GameManager>();
        bgmusic = GetComponent<AudioSource>();

        prevVolume = gamemanager.volume;
    }

    private void LateUpdate()
    {
        if(gamemanager.level == 0 && bgmusic.isPlaying)
        {
            bgmusic.Stop();
            Destroy(gameObject);
            return;
        }
        if (prevVolume != gamemanager.volume)
        {
            bgmusic.volume = gamemanager.volume;
            prevVolume = gamemanager.volume;
        }
    }

    void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        if(loadedCount > 0)
        {
            gamemanager = FindObjectOfType<GameManager>();
            gamemanager.volumeSlider.value = prevVolume;
        }
        loadedCount++;
        //prevVolume = gamemanager.volume;
    }

    void OnEnable()
    {
        Debug.Log("OnEnable called");
        SceneManager.sceneLoaded += OnSceneLoaded;
    }
}
