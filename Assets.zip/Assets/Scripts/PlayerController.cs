using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class PlayerController : MonoBehaviour
{
    private Rigidbody2D rb;

    // unstable values
    [Range(-1, 1)]
    public float gravity_direction;
    public float accelaration;

    // unstable values
    public bool updateJumpForce;
    public float jump_force;
    public Vector2 jumpForceRange;
    public float jumpForceTime;
    private float jumpForceTimer;
    public bool jumpForceUp;
    public Slider jumpForceSlider;
    public GameObject jumpForceParticles;

    public bool updateGravityStrength;
    public float gravity_strength;
    public Vector2 gravityStrengthRange;
    public float gravityStrengthTime;
    private float gravityStrengthTimer;
    public bool gravityStrengthUp;
    public Slider gravityStrengthSlider;
    public GameObject gravityStrengthParticles;

    public bool updateSpeed;
    public float speed;
    public Vector2 speedRange;
    public float speedTime;
    private float speedTimer;
    public bool speedUp;
    public Slider speedSlider;
    public GameObject speedParticles;

    // state values
    public float coyoteTime;
    float coyoteTimer;
    bool jump;
    float move;
    bool grounded;
    bool dead;
    bool end;
    Vector3 endPos;
    float rev = 1;
    //SpriteRenderer inner;

    public GameObject sprite, spriteInner;
    public GameObject deathParticles;
    public GameObject followPlayer;

    // world values
    public LayerMask groundLayer;
    public LayerMask damageLayer;
    public GameManager gamemanager;

    // sounds
    public AudioSource jumpSfx, endSfx, groundSfx, deathSfx;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        //inner = transform.GetChild(1).GetComponent<SpriteRenderer>();
        //followPlayer = FindObjectOfType<FollowPlayer>().gameObject;
    }

    void Update()
    {
        //dead = Physics2D.IsTouchingLayers(GetComponent<BoxCollider2D>(), damageLayer);
        if (dead) return;
        if (end)
        {
            transform.position = Vector3.Lerp(transform.position, endPos, .05f);
            return;
        }

        jumpForceSlider.gameObject.SetActive(updateJumpForce);
        jumpForceParticles.SetActive(updateJumpForce);

        gravityStrengthSlider.gameObject.SetActive(updateGravityStrength);
        gravityStrengthParticles.SetActive(updateGravityStrength);

        speedSlider.gameObject.SetActive(updateSpeed);
        speedParticles.SetActive(updateSpeed);

        if (updateJumpForce) UpdateValue(ref jump_force, ref jumpForceRange, ref jumpForceTime, ref jumpForceTimer, ref jumpForceUp, ref jumpForceSlider);
        if (updateGravityStrength) UpdateValue(ref gravity_strength, ref gravityStrengthRange, ref gravityStrengthTime, ref gravityStrengthTimer, ref gravityStrengthUp, ref gravityStrengthSlider);
        if (updateSpeed) UpdateValue(ref speed, ref speedRange, ref speedTime, ref speedTimer, ref speedUp, ref speedSlider);

        if(gravity_strength > 0) { rev = 1; }
        else if (gravity_strength < 0) { rev = -1; }

        // general
        if (Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.Space))
        {
            jump = true;
        }
        if (Input.GetKeyUp(KeyCode.W) || Input.GetKeyUp(KeyCode.UpArrow) || Input.GetKeyUp(KeyCode.Space))
        {
            jump = false;
        }
        move = Input.GetAxisRaw("Horizontal");
        grounded = Physics2D.Raycast(transform.position, rev * Vector3.down, .6f, groundLayer);

        if(grounded)
        {
            coyoteTimer = 0;
        }
        else
        {
            coyoteTimer += Time.deltaTime;
        }

        rb.gravityScale = gravity_strength * gravity_direction;
    }

    void UpdateValue(ref float value, ref Vector2 Range, ref float vTime, ref float Timer, ref bool Up, ref Slider vSlider)
    {
        Timer += Time.deltaTime; // increase timer
        if (Timer > vTime) // reset timer
        {
            Up = !Up;
            Timer = 0;
        }
        if (Up) // increase value
        {
            value = Mathf.Lerp(Range.x, Range.y, Timer / vTime);
        }
        else // decrease value
        {
            value = Mathf.Lerp(Range.y, Range.x, Timer / vTime);
        }
        // update slider
        vSlider.minValue = Range.x;
        vSlider.maxValue = Range.y;
        vSlider.value = value;
    }

    float Remap(float iMin, float iMax, float oMin, float oMax, float value)
    {
        float t = Mathf.InverseLerp(iMin, iMax, value);
        float output = Mathf.Lerp(oMin, oMax, t);

        return output;
    }

    private void FixedUpdate()
    {
        Move();
        Jump();
        Roll();
    }

    void Move()
    {
        rb.velocity = new Vector2(move*speed, rb.velocity.y);

        if (followPlayer != null && !followPlayer.activeSelf && move != 0)
        {
            followPlayer.SetActive(true);
        }
    }

    void Jump()
    {
        if(jump && (grounded ||  coyoteTimer < coyoteTime))
        {
            rb.velocity = new Vector2(rb.velocity.x, rev * jump_force);
            jump = false;
            coyoteTimer = coyoteTime + 1;

            jumpSfx.pitch = Remap(jumpForceRange.y, jumpForceRange.x, .5f, 1.3f, jump_force);
            jumpSfx.PlayOneShot(jumpSfx.clip, gamemanager.volume);

            if(followPlayer != null && !followPlayer.activeSelf)
            {
                followPlayer.SetActive(true);
            }
        }
    }

    void Roll()
    {
        spriteInner.transform.RotateAround(spriteInner.transform.position, Vector3.back, rev * (move * speed));
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.tag == "damage")
        {
            dead = true;
            deathSfx.PlayOneShot(deathSfx.clip, gamemanager.volume);
            sprite.SetActive(false);
            spriteInner.SetActive(false);
            deathParticles.SetActive(true);
            GetComponent<BoxCollider2D>().enabled = false;
            rb.velocity = Vector2.zero;
            rb.gravityScale = 0;
            //Destroy(rb);
            rb.simulated = false;
            jumpForceParticles.SetActive(false);
            speedParticles.SetActive(false);
            gravityStrengthParticles.SetActive(false);
            gamemanager.RestartScene();
        }
        else if (collision.tag == "end")
        {
            end = true;
            endSfx.PlayOneShot(endSfx.clip, gamemanager.volume);
            endPos = collision.transform.position;
            GetComponent<BoxCollider2D>().enabled = false;
            rb.velocity = Vector2.zero;
            rb.gravityScale = 0;
            //Destroy(rb);
            rb.simulated = false;
            jumpForceParticles.SetActive(false);
            speedParticles.SetActive(false);
            gravityStrengthParticles.SetActive(false);
            gamemanager.NextScene();
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "ground")
        {
            //groundSfx.PlayOneShot(groundSfx.clip, gamemanager.volume);
        }
    }
}
