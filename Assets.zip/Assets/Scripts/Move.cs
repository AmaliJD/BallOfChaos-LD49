using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Move : MonoBehaviour
{
    public List<Vector4> moves;
    public float rotateAnglePerFrame;

    private void Start()
    {
        StartCoroutine(Movement());
    }

    private void Update()
    {
        transform.RotateAround(transform.position, Vector3.back, rotateAnglePerFrame);
    }

    public IEnumerator Movement()
    {
        int i = 0;
        while(true)
        {
            float x = moves[i].x;
            float y = moves[i].y;
            float t = moves[i].z;
            float w = moves[i].w;

            float _x = transform.position.x;
            float _y = transform.position.y;

            float time = 0;
            if(t == 0)
            {
                transform.position = new Vector2(_x + x, _y + y);
            }
            else
            {
                while (time <= t)
                {
                    transform.position = Vector2.Lerp(new Vector2(_x, _y), new Vector2(_x + x, _y + y), time / t);
                    time += Time.deltaTime;
                    yield return null;
                }
            }

            time = 0;
            while (time <= w)
            {
                time += Time.deltaTime;
                yield return null;
            }

            i++;
            if (i >= moves.Count) i = 0;
        }
    }
}
