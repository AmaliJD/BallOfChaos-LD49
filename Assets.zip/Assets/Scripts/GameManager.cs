using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public int level;

    [Range(0,1)]
    public float volume;
    public Slider volumeSlider;
    private Button quit;

    public GameObject player, circle, mask, pauseScreen;

    private bool pause;

    private void Awake()
    {
        circle.transform.position = player.transform.position;
        mask.transform.localScale = Vector3.zero;

        quit = pauseScreen.transform.GetChild(3).GetComponent<Button>();
        quit.onClick.AddListener(Quit);
    }

    private void Start()
    {
        StartCoroutine(Circle(.5f, 0, 80, 1.5f, 0));
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.R))
        {
            Time.timeScale = 1;
            pause = false;
            RestartScene();
        }
        else if (Input.GetKeyDown(KeyCode.Escape) && level != 0)
        {
            pause = !pause;
        }

        if(pause)
        {
            Time.timeScale = 0;
            pauseScreen.SetActive(true);
        }
        else
        {
            Time.timeScale = 1;
            pauseScreen.SetActive(false);
        }

        volume = volumeSlider.value;
    }

    public void RestartScene()
    {
        StopAllCoroutines();
        StartCoroutine(Circle(0, 80, 0, 1f, 1));
    }

    public void NextScene()
    {
        StopAllCoroutines();
        StartCoroutine(Circle(0, 80, 0, 1f, 2));
    }

    public void Quit()
    {
        Time.timeScale = 1;
        pause = false;
        StopAllCoroutines();
        StartCoroutine(Circle(0, 80, 0, 1f, 3));
    }

    IEnumerator Circle(float wait, float start, float end, float fadetime, int restart)
    {
        circle.transform.position = player.transform.position;

        float time = 0;
        
        while (time <= wait)
        {
            time += Time.deltaTime;
            yield return null;
        }

        time = 0;

        while (time <= fadetime)
        {
            mask.transform.localScale = Vector3.Lerp(new Vector3(start, start, start), new Vector3(end, end, end), time / fadetime); 
            time += Time.deltaTime;
            yield return null;
        }

        mask.transform.localScale = new Vector3(end, end, end);

        /*if(restart)
        {
            time = 0;
            while (time <= .5f)
            {
                time += Time.deltaTime;
                yield return null;
            }
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }*/
        if(restart == 1)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
        else if (restart == 2)
        {
            if(level == 18)
            {
                SceneManager.LoadScene("MainMenu");
            }
            else
            {
                SceneManager.LoadScene("Level" + (level + 1));
            }
        }
        else if (restart == 3)
        {
            SceneManager.LoadScene("MainMenu");
        }
    }
}
