using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowPlayer : MonoBehaviour
{
    Transform player;
    //Rigidbody2D rb;
    List<Vector2> followPoints;
    float time = 0, waittime = 0;
    public float followTime, waitTime;
    private Vector2 curr, follow;

    public AudioSource evilSfx;
    GameManager gamemanager;


    void Awake()
    {
        player = FindObjectOfType<PlayerController>().transform;
        gamemanager = FindObjectOfType<GameManager>();
        //rb = GetComponent<Rigidbody2D>();
        followPoints = new List<Vector2>();
        curr = transform.position;
        follow = player.position;
    }

    void Update()
    {
        transform.RotateAround(transform.position, Vector3.back, 5);

        waittime += Time.deltaTime;

        followPoints.Add(player.position);

        if (waittime >= waitTime)
        {
            curr = followPoints[0];
            follow = followPoints[0];
            followPoints.RemoveAt(0);

            transform.position = follow;
        }
        else
        {
            transform.position = Vector2.Lerp(curr, follow, waittime / waitTime);
        }
    }
}
